import tkinter as tk
from tkinter import ttk, messagebox
from tkinter import filedialog
import cv2
import face_recognition
import numpy as np
import pickle
import os
from datetime import datetime
import csv

class AttendanceSystemGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Student Attendance System")
        self.root.geometry("800x600")
        
        # Set up data directories
        self.data_dir = os.path.join(os.path.dirname(__file__), 'data')
        os.makedirs(self.data_dir, exist_ok=True)
        
        # Initialize student dictionary
        self.students = {}
        self.load_students()
        
        # Create main containers
        self.create_widgets()
        
    def create_widgets(self):
        # Create notebook for tabs
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(pady=10, expand=True)
        
        # Register tab
        self.register_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.register_frame, text="Register Student")
        
        # Attendance tab
        self.attendance_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.attendance_frame, text="Take Attendance")
        
        # Setup registration widgets
        self.setup_registration_tab()
        
        # Setup attendance widgets
        self.setup_attendance_tab()
    
    def setup_registration_tab(self):
        # Student ID
        ttk.Label(self.register_frame, text="Student ID:").pack(pady=5)
        self.student_id_entry = ttk.Entry(self.register_frame)
        self.student_id_entry.pack(pady=5)
        
        # Student Name
        ttk.Label(self.register_frame, text="Student Name:").pack(pady=5)
        self.student_name_entry = ttk.Entry(self.register_frame)
        self.student_name_entry.pack(pady=5)
        
        # Photo upload button
        self.photo_path = tk.StringVar()
        ttk.Button(self.register_frame, 
                   text="Upload Photo", 
                   command=self.upload_photo).pack(pady=10)
        
        # Register button
        ttk.Button(self.register_frame, 
                   text="Register Student", 
                   command=self.register_student).pack(pady=10)
        
        # Preview label
        self.preview_label = ttk.Label(self.register_frame, text="No photo selected")
        self.preview_label.pack(pady=10)
    
    def setup_attendance_tab(self):
        # Start camera button
        ttk.Button(self.attendance_frame, 
                   text="Start Camera", 
                   command=self.start_attendance).pack(pady=10)
        
        # Attendance list
        self.attendance_tree = ttk.Treeview(self.attendance_frame, 
                                          columns=("ID", "Name", "Time"),
                                          show="headings")
        self.attendance_tree.heading("ID", text="Student ID")
        self.attendance_tree.heading("Name", text="Name")
        self.attendance_tree.heading("Time", text="Time")
        self.attendance_tree.pack(pady=10, fill=tk.BOTH, expand=True)
    
    def upload_photo(self):
        file_path = filedialog.askopenfilename(
            filetypes=[("Image files", "*.jpg *.jpeg *.png")]
        )
        if file_path:
            self.photo_path.set(file_path)
            self.preview_label.config(text=f"Selected: {os.path.basename(file_path)}")
    
    def register_student(self):
        student_id = self.student_id_entry.get().strip()
        name = self.student_name_entry.get().strip()
        photo_path = self.photo_path.get()
        
        if not all([student_id, name, photo_path]):
            messagebox.showerror("Error", "Please fill all fields and upload a photo")
            return
        
        # Load and encode face
        image = face_recognition.load_image_file(photo_path)
        face_encodings = face_recognition.face_encodings(image)
        
        if not face_encodings:
            messagebox.showerror("Error", "No face detected in the photo")
            return
        
        # Store student data
        self.students[student_id] = {
            'name': name,
            'face_encoding': face_encodings[0],
            'attendance': []
        }
        
        self.save_students()
        messagebox.showinfo("Success", f"Successfully registered {name}")
        
        # Clear fields
        self.student_id_entry.delete(0, tk.END)
        self.student_name_entry.delete(0, tk.END)
        self.photo_path.set("")
        self.preview_label.config(text="No photo selected")
    
    def start_attendance(self):
        cap = cv2.VideoCapture(0)
        attendance_marked = False
        recognition_start = None
        RECOGNITION_DURATION = 2  # Seconds to confirm recognition
        
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            
            # Find faces in frame
            face_locations = face_recognition.face_locations(frame)
            face_encodings = face_recognition.face_encodings(frame, face_locations)
            
            current_time = datetime.now()
            
            for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
                for student_id, student_data in self.students.items():
                    match = face_recognition.compare_faces(
                        [student_data['face_encoding']], 
                        face_encoding, 
                        tolerance=0.6
                    )[0]
                    
                    if match:
                        name = student_data['name']
                        # Draw box around face
                        cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
                        cv2.putText(frame, name, (left, top - 10),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 255, 0), 2)
                        
                        # Start recognition timer if not started
                        if recognition_start is None:
                            recognition_start = current_time
                        
                        # Check if face has been recognized for sufficient duration
                        if (current_time - recognition_start).total_seconds() >= RECOGNITION_DURATION:
                            if not attendance_marked:
                                self.mark_attendance(student_id)
                                attendance_marked = True
                                
                                # Show success message
                                cv2.putText(frame, "Attendance Marked!", 
                                        (10, frame.shape[0] - 20),
                                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
                                cv2.imshow('Attendance', frame)
                                cv2.waitKey(1000)  # Show success message for 1 second
                                
                                # Clean up and return
                                cap.release()
                                cv2.destroyAllWindows()
                                return
                    else:
                        # Reset recognition timer if face not matched
                        recognition_start = None
            
            cv2.imshow('Attendance', frame)
            
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
        
        cap.release()
        cv2.destroyAllWindows()
    
    def mark_attendance(self, student_id):
        current_time = datetime.now().strftime("%H:%M:%S")
        
        # Update treeview
        self.attendance_tree.insert("", "end", values=(
            student_id,
            self.students[student_id]['name'],
            current_time
        ))
        
        # Save to CSV
        self.save_attendance_record(student_id, current_time)
    
    def save_attendance_record(self, student_id, time):
        date = datetime.now().strftime("%Y-%m-%d")
        filename = os.path.join(self.data_dir, f"attendance_{date}.csv")
        
        # Create file with headers if it doesn't exist
        if not os.path.exists(filename):
            with open(filename, 'w', newline='') as file:
                writer = csv.writer(file)
                writer.writerow(['Student ID', 'Name', 'Time'])
        
        # Append attendance record
        with open(filename, 'a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([
                student_id,
                self.students[student_id]['name'],
                time
            ])
    
    def save_students(self):
        students_file = os.path.join(self.data_dir, 'students.pkl')
        with open(students_file, 'wb') as f:
            pickle.dump(self.students, f)
    
    def load_students(self):
        students_file = os.path.join(self.data_dir, 'students.pkl')
        try:
            with open(students_file, 'rb') as f:
                self.students = pickle.load(f)
        except FileNotFoundError:
            self.students = {}

def main():
    root = tk.Tk()
    app = AttendanceSystemGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()