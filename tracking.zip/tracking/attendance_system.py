import cv2
import numpy as np
import os
import pickle
from datetime import datetime
import csv
from student import Student
import tkinter as tk
from tkinter import filedialog
import face_recognition 

class AttendanceSystem:
    def __init__(self):
        self.data_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data')
        self.attendance_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'attendance')
        self.students = {}
        self.load_students()
        
        # Create necessary directories
        os.makedirs(self.data_dir, exist_ok=True)
        os.makedirs(self.attendance_dir, exist_ok=True)
    
    def register_student(self):
        """Register a new student with photo upload."""
        # Get student info
        student_id = input("Enter Student ID: ")
        name = input("Enter Student Name: ")
        
        # Open file dialog for image selection
        root = tk.Tk()
        root.withdraw()
        file_path = filedialog.askopenfilename(
            title="Select Student Photo",
            filetypes=[("Image files", "*.jpg *.jpeg *.png")]
        )
        
        if not file_path:
            print("No image selected. Registration cancelled.")
            return
        
        # Load and process reference image
        reference_image = cv2.imread(file_path)
        if reference_image is None:
            print("Error loading image.")
            return
            
        # Create student object
        student = Student(student_id, name, reference_image)
        self.students[student_id] = student
        
        # Save students data
        self.save_students()
        print(f"Successfully registered {name} (ID: {student_id})")
    
    def take_attendance(self):
        """Take attendance using webcam face matching."""
        cap = cv2.VideoCapture(0)
        
        while True:
            ret, frame = cap.read()
            if not ret:
                print("Failed to grab frame")
                break
                
            # Find faces in current frame
            frame_face_locations = face_recognition.face_locations(frame)
            if frame_face_locations:
                frame_encodings = face_recognition.face_encodings(frame, frame_face_locations)
                
                for (top, right, bottom, left), face_encoding in zip(frame_face_locations, frame_encodings):
                    matched_student = None
                    
                    # Check against all registered students
                    for student_id, student in self.students.items():
                        ref_encoding = face_recognition.face_encodings(student.reference_image)[0]
                        match = face_recognition.compare_faces([ref_encoding], face_encoding, tolerance=0.6)[0]
                        
                        if match:
                            matched_student = student
                            break
                    
                    # Draw rectangle around face
                    cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
                    
                    if matched_student:
                        # Draw name and ID
                        cv2.putText(frame, f"{matched_student.name}", (left, top - 10),
                                  cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
                        
                        # Mark attendance when 'a' is pressed
                        if cv2.waitKey(1) & 0xFF == ord('a'):
                            self.mark_attendance(matched_student)
            
            cv2.imshow('Attendance System', frame)
            
            # Quit if 'q' is pressed
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
        
        cap.release()
        cv2.destroyAllWindows()
    
    def mark_attendance(self, student):
        """Record attendance in CSV file."""
        date = datetime.now().strftime("%Y-%m-%d")
        time = datetime.now().strftime("%H:%M:%S")
        attendance_file = os.path.join(self.attendance_dir, f"attendance_{date}.csv")
        
        # Check if already marked attendance
        if self.check_existing_attendance(attendance_file, student.student_id):
            print(f"Attendance already marked for {student.name}")
            return
        
        # Write attendance
        with open(attendance_file, 'a', newline='') as f:
            writer = csv.writer(f)
            if os.path.getsize(attendance_file) == 0:
                writer.writerow(['Student ID', 'Name', 'Time'])
            writer.writerow([student.student_id, student.name, time])
        
        print(f"Marked attendance for {student.name}")
    
    def check_existing_attendance(self, file_path, student_id):
        """Check if student already marked attendance today."""
        if not os.path.exists(file_path):
            return False
            
        with open(file_path, 'r') as f:
            reader = csv.reader(f)
            next(reader)  # Skip header
            return any(row[0] == student_id for row in reader)
    
    def save_students(self):
        """Save registered students to file."""
        with open(os.path.join(self.data_dir, 'students.pkl'), 'wb') as f:
            pickle.dump(self.students, f)
    
    def load_students(self):
        """Load registered students from file."""
        try:
            with open(os.path.join(self.data_dir, 'students.pkl'), 'rb') as f:
                self.students = pickle.load(f)
        except FileNotFoundError:
            self.students = {}