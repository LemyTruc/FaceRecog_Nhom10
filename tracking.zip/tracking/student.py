from dataclasses import dataclass
import numpy as np

@dataclass
class Student:
    student_id: str
    name: str
    reference_image: np.ndarray