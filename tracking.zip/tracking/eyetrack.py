import cv2 
import mediapipe as mp
import time
import numpy as np
from collections import deque

class EyeTrackingTest:
    def __init__(self):
        self.cam = cv2.VideoCapture(0)
        # Initialize MediaPipe FaceMesh with iris landmarks
        self.face_mesh = mp.solutions.face_mesh.FaceMesh(
            max_num_faces=1,
            refine_landmarks=True,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5
        )
        self.directions = deque(['LEFT', 'RIGHT', 'UP', 'DOWN'])
        self.current_direction = None
        self.direction_start_time = None
        self.direction_duration = 2
        self.completed_directions = set()
        
        # Define eye landmarks for both eyes
        self.LEFT_EYE = [362, 382, 381, 380, 374, 373, 390, 249, 263, 466, 388, 387, 386, 385, 384, 398]
        self.RIGHT_EYE = [33, 7, 163, 144, 145, 153, 154, 155, 133, 173, 157, 158, 159, 160, 161, 246]
        self.LEFT_IRIS = [474, 475, 476, 477]
        self.RIGHT_IRIS = [469, 470, 471, 472]
        
    def get_iris_position(self, landmarks, frame_w, frame_h):
        # Get both eye landmarks
        left_eye_points = np.array([(landmarks[idx].x * frame_w, landmarks[idx].y * frame_h) 
                                  for idx in self.LEFT_EYE])
        right_eye_points = np.array([(landmarks[idx].x * frame_w, landmarks[idx].y * frame_h) 
                                   for idx in self.RIGHT_EYE])
        
        left_iris_points = np.array([(landmarks[idx].x * frame_w, landmarks[idx].y * frame_h) 
                                   for idx in self.LEFT_IRIS])
        right_iris_points = np.array([(landmarks[idx].x * frame_w, landmarks[idx].y * frame_h) 
                                    for idx in self.RIGHT_IRIS])
        
        # Calculate eye centers
        left_eye_center = np.mean(left_eye_points, axis=0)
        right_eye_center = np.mean(right_eye_points, axis=0)
        left_iris_center = np.mean(left_iris_points, axis=0)
        right_iris_center = np.mean(right_iris_points, axis=0)
        
        # Calculate relative positions for both eyes
        left_eye_width = np.max(left_eye_points[:, 0]) - np.min(left_eye_points[:, 0])
        right_eye_width = np.max(right_eye_points[:, 0]) - np.min(right_eye_points[:, 0])
        left_eye_height = np.max(left_eye_points[:, 1]) - np.min(left_eye_points[:, 1])
        right_eye_height = np.max(right_eye_points[:, 1]) - np.min(right_eye_points[:, 1])
        
        # Calculate relative positions
        left_x_rel = (left_iris_center[0] - left_eye_center[0]) / (left_eye_width / 2)
        right_x_rel = (right_iris_center[0] - right_eye_center[0]) / (right_eye_width / 2)
        left_y_rel = (left_iris_center[1] - left_eye_center[1]) / (left_eye_height / 2)
        right_y_rel = (right_iris_center[1] - right_eye_center[1]) / (right_eye_height / 2)
        
        # Average the relative positions from both eyes
        x_rel = (left_x_rel + right_x_rel) / 2
        y_rel = (left_y_rel + right_y_rel) / 2
        
        # Return eye measurements for visualization
        return {
            'direction': self._get_direction(x_rel, y_rel),
            'left_eye': {'center': left_eye_center, 'iris': left_iris_center},
            'right_eye': {'center': right_eye_center, 'iris': right_iris_center}
        }
    
    def _get_direction(self, x_rel, y_rel):
        # Adjusted thresholds for better detection
        if x_rel < -0.15:
            return 'LEFT'
        elif x_rel > 0.15:
            return 'RIGHT'
        elif y_rel < -0.15:
            return 'UP'
        elif y_rel > 0.15:
            return 'DOWN'
        return 'CENTER'
    
    def draw_eye_tracking(self, frame, eye_data):
        # Draw iris centers and direction vectors for both eyes
        for eye in ['left_eye', 'right_eye']:
            center = tuple(map(int, eye_data[eye]['center']))
            iris = tuple(map(int, eye_data[eye]['iris']))
            
            # Draw eye center
            cv2.circle(frame, center, 3, (255, 0, 0), -1)
            # Draw iris center
            cv2.circle(frame, iris, 3, (0, 255, 0), -1)
            # Draw line from eye center to iris center
            cv2.line(frame, center, iris, (0, 255, 255), 1)

    def draw_instruction(self, frame, text, color=(255, 255, 255)):
        h, w = frame.shape[:2]
        # Create semi-transparent overlay
        overlay = frame.copy()
        cv2.rectangle(overlay, (0, 0), (w, 100), (0, 0, 0), -1)
        cv2.addWeighted(overlay, 0.5, frame, 0.5, 0, frame)
        
        # Add text and progress
        cv2.putText(frame, f"Look {text}", (int(w/2 - 100), 40),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, color, 2)
        progress = f"Completed: {len(self.completed_directions)}/4"
        cv2.putText(frame, progress, (int(w/2 - 80), 80),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (200, 200, 200), 2)
        
    def run(self):
        try:
            while True:
                _, frame = self.cam.read()
                frame = cv2.flip(frame, 1)
                rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                output = self.face_mesh.process(rgb_frame)
                frame_h, frame_w, _ = frame.shape
                
                current_time = time.time()
                if not self.current_direction and self.directions:
                    self.current_direction = self.directions[0]
                    self.direction_start_time = current_time
                
                if output.multi_face_landmarks:
                    landmarks = output.multi_face_landmarks[0].landmark
                    
                    # Get eye tracking data
                    eye_data = self.get_iris_position(landmarks, frame_w, frame_h)
                    current_look = eye_data['direction']
                    
                    # Draw eye tracking visualization
                    self.draw_eye_tracking(frame, eye_data)
                    
                    # Draw debug info
                    cv2.putText(frame, f"Looking: {current_look}", (10, frame_h - 20),
                              cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
                    
                    if current_look == self.current_direction:
                        color = (0, 255, 0)
                        if current_time - self.direction_start_time > self.direction_duration:
                            self.completed_directions.add(self.current_direction)
                            if self.directions:
                                self.directions.popleft()
                                self.current_direction = None
                    else:
                        color = (0, 0, 255)
                    
                    if self.current_direction:
                        self.draw_instruction(frame, self.current_direction, color)
                    
                    if len(self.completed_directions) >= 4:
                        cv2.putText(frame, "Test Completed!", (int(frame_w/2 - 150), int(frame_h/2)),
                                  cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 255, 0), 2)
                        cv2.imshow('Eye Direction Test', frame)
                        cv2.waitKey(2000)
                        break
                else:
                    self.draw_instruction(frame, "Face not detected", (0, 0, 255))
                
                cv2.imshow('Eye Direction Test', frame)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
                    
        finally:
            self.cam.release()
            cv2.destroyAllWindows()

if __name__ == "__main__":
    test = EyeTrackingTest()
    test.run()


